package com.example.bai_so_1;

public class SinhVien {
    public String TenSv;
    public String GioiTinh;
    public String NamSinh;

    public SinhVien(String tenSv, String gioiTinh, String namSinh) {
        TenSv = tenSv;
        GioiTinh = gioiTinh;
        NamSinh = namSinh;
    }
}
