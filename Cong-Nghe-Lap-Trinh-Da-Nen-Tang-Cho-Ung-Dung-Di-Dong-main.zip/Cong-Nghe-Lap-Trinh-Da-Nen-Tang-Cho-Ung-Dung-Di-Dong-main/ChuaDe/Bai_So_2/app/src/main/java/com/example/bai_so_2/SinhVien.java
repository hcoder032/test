package com.example.bai_so_2;

public class SinhVien {
    public String MaSv;
    public String TenSv;
    public String Tuoi;

    public SinhVien(String maSv, String tenSv, String tuoi) {
        MaSv = maSv;
        TenSv = tenSv;
        Tuoi = tuoi;
    }
}
